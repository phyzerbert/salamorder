<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="MultiStore Management System">
    <meta name="author" content="Yuyuan Zhang">

    <title><?php echo e(config("app.name")); ?></title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('master/lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('master/css/bracket.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('master/lib/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('master/lib/popper.js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('master/lib/bootstrap/bootstrap.js')); ?>"></script>

</body>
<?php echo $__env->yieldContent('script'); ?>
</html>
<?php /**PATH E:\2019-Jun\Store\Source\Salam_Order\resources\views/layouts/auth.blade.php ENDPATH**/ ?>