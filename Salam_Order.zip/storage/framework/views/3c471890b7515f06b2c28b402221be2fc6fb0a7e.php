<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('master/lib/vuejs/vue.js')); ?>"></script>
    <script src="<?php echo e(asset('master/lib/vuejs/axios.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="<?php echo e(route('pre_order.index')); ?>"><?php echo e(__('page.purchase_order')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.receive')); ?></a>
            </nav>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="row mg-t-20">
                    <div class="col-md-12 table-responsive">
                        <div class="pd-t-20 py-3">
                            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-info-circle"></i> <?php echo e(__('page.receive')); ?></h4>
                        </div>
                        <form action="<?php echo e(route('pre_order.save_receive')); ?>" method="post" id="app">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($order->id); ?>" id="order_id" />
                            <table class="table table-bordered table-colored table-info">
                                <thead>
                                    <tr>
                                        <th class="wd-40">#</th>
                                        <th><?php echo e(__('page.product_name_code')); ?></th>
                                        <th><?php echo e(__('page.product_cost')); ?></th>
                                        <th><?php echo e(__('page.discount')); ?></th>
                                        <th><?php echo e(__('page.ordered_quantity')); ?></th>
                                        <th><?php echo e(__('page.received_quantity')); ?></th>
                                        <th><?php echo e(__('page.balance')); ?></th>
                                        <th><?php echo e(__('page.receive')); ?></th>
                                        <th><?php echo e(__('page.subtotal')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $total_discount = 0;
                                        $total_amount = 0;
                                    ?>
                                        <tr v-for="(item,i) in order_items" :key="i">
                                            <td>
                                                <label class="ckbox ckbox-success">
                                                    <input type="checkbox" :name="'item[' + item.item_id +']'" :value="item.item_id"><span></span>
                                                </label>
                                            </td>
                                            <td>{{item.product_name_code}}</td>
                                            <td>{{formatPrice(item.cost)}}</td>
                                            <td>{{item.discount_string}}</td>
                                            <td>{{item.ordered_quantity}}</td>
                                            <td>{{item.received_quantity}}</td>
                                            <td>{{item.balance}}</td>
                                            <td class="py-2"><input type="number" class="form-control" :name="'receive_quantity[' + item.item_id + ']'" v-model="item.receive_quantity" min="0" :max="item.balance"></td>
                                            <td>
                                                {{formatPrice(item.sub_total)}}
                                                <input type="hidden" :name="'subtotal[' + item.item_id + ']'" :value="item.sub_total" />
                                            </td>
                                        </tr>
                                    <tr>
                                        <td colspan="3" class="tx-bold"><?php echo e(__('page.total')); ?> </td>
                                        <td>{{formatPrice(total.discount)}}</td>
                                        <td colspan="4"></td>
                                        <td>{{formatPrice(total.cost)}}</td>
                                    </tr>
                                </tbody>
                                <tfoot class="tx-bold tx-black">
                                    <tr>
                                        <td colspan="8" style="text-align:right"><?php echo e(__('page.total_discount')); ?> </td>
                                        <td>
                                            {{formatPrice(discount)}}
                                            <input type="hidden" name="discount" :value="discount" />
                                            <input type="hidden" name="discount_string" :value="discount_string" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="8" style="text-align:right"><?php echo e(__('page.total_amount')); ?> </td>
                                        <td>
                                            {{formatPrice(grand_total)}}
                                            <input type="hidden" name="grand_total" :value="grand_total" />
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mg-b-10-force">
                                        <label class="form-control-label"><?php echo e(__('page.store')); ?>:</label>
                                        <select class="form-control select2" name="store" data-placeholder="<?php echo e(__('page.select_store')); ?>">
                                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php if(old('store') == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if ($errors->has('store')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('store'); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-4 text-right">
                                    <a href="<?php echo e(route('pre_order.index')); ?>" class="btn btn-success"><i class="menu-item-icon icon ion-clipboard tx-16"></i>  <?php echo e(__('page.purchase_order')); ?></a>
                                    <button type="submit" class="btn btn-primary ml-3"><i class="menu-item-icon icon ion-archive tx-16"></i>  <?php echo e(__('page.receive')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
            
    });
</script>
<script src="<?php echo e(asset('js/pre_order_receive.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\Salam_Order\resources\views/pre_order/receive.blade.php ENDPATH**/ ?>