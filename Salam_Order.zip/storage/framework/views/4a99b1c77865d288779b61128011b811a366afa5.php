<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.purchase_order')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-credit-card"></i>  <?php echo e(__('page.purchase_order')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                    <?php echo $__env->make('pre_order.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($role == 'user'): ?>
                        <a href="<?php echo e(route('pre_order.create')); ?>" class="btn btn-success btn-sm float-right ml-3 mg-b-5" id="btn-add"><i class="fa fa-plus mg-r-2"></i> <?php echo e(__('page.add_new')); ?></a>
                    <?php endif; ?>
                    <?php echo $__env->make('elements.keyword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th>
                                    <?php echo e(__('page.date')); ?>

                                    <span class="sort-date float-right">
                                        <?php if($sort_by_date == 'desc'): ?>
                                            <i class="fa fa-angle-up"></i>
                                        <?php elseif($sort_by_date == 'asc'): ?>
                                            <i class="fa fa-angle-down"></i>
                                        <?php endif; ?>
                                    </span>
                                </th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.supplier')); ?></th>
                                <th><?php echo e(__('page.grand_total')); ?></th>
                                <th><?php echo e(__('page.received')); ?></th>
                                <th><?php echo e(__('page.balance')); ?></th>
                                <th><?php echo e(__('page.status')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $footer_grand_total = $footer_received = $footer_balance = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    // $received = $item->payments()->sum('amount');
                                    $received = $item->purchases()->sum('grand_total');
                                    $grand_total = $item->grand_total;
                                    $balance = $grand_total - $received;
                                    $footer_grand_total += $grand_total;
                                    // $footer_paid += $received;
                                    $footer_balance += $balance;
                                ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="timestamp"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no"><?php echo e($item->reference_no); ?></td>
                                    <td class="supplier" data-id="<?php echo e($item->supplier_id); ?>"><?php echo e($item->supplier->company); ?></td>
                                    <td class="grand_total"> <?php echo e(number_format($grand_total)); ?> </td>
                                    <td class="received"> <?php echo e(number_format($received)); ?> </td>
                                    <td class="balance" data-value="<?php echo e($balance); ?>"> <?php echo e(number_format($balance)); ?> </td>
                                    <td class="status">
                                        <?php if($received == 0): ?>
                                            <span class="badge badge-danger"><?php echo e(__('page.pending')); ?></span>
                                        <?php elseif($received < $grand_total): ?>
                                            <span class="badge badge-primary"><?php echo e(__('page.partial')); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-success"><?php echo e(__('page.received')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-2" align="center">
                                        <div class="dropdown">
                                            <a href="#" class="btn btn-info btn-with-icon nav-link" data-toggle="dropdown">
                                                <div class="ht-30">
                                                    <span class="icon wd-30"><i class="fa fa-send"></i></span>
                                                    <span class="pd-x-15"><?php echo e(__('page.action')); ?></span>
                                                </div>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-header action-dropdown bd-t-1">
                                                <ul class="list-unstyled user-profile-nav">
                                                    <li><a href="<?php echo e(route('pre_order.detail', $item->id)); ?>"><i class="icon ion-eye  "></i> <?php echo e(__('page.details')); ?></a></li>
                                                    <li><a href="<?php echo e(route('received_order.index')); ?>?order_id=<?php echo e($item->id); ?>"><i class="icon ion-cash"></i> <?php echo e(__('page.received_list')); ?></a></li>
                                                    <li><a href="<?php echo e(route('pre_order.receive', $item->id)); ?>"><i class="icon ion-cash"></i> <?php echo e(__('page.receive')); ?></a></li>                                                    
                                                    <li><a href="<?php echo e(route('pre_order.edit', $item->id)); ?>"><i class="icon ion-compose"></i> <?php echo e(__('page.edit')); ?></a></li>
                                                    <li><a href="<?php echo e(route('pre_order.delete', $item->id)); ?>" onclick="return window.confirm('Are you sure?')"><i class="icon ion-trash-a"></i> <?php echo e(__('page.delete')); ?></a></li>                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($footer_grand_total)); ?></td>
                                <td><?php echo e(number_format($footer_received)); ?></td>
                                <td><?php echo e(number_format($footer_balance)); ?></td>
                                <td colspan="2"></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([
                                'company_id' => $company_id,
                                'supplier_id' => $supplier_id,
                                'reference_no' => $reference_no,
                                'period' => $period,
                                // 'expiry_period' => $expiry_period,
                            ])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/styling/uniform.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $("#payment_form input.date").datetimepicker({
            dateFormat: 'yy-mm-dd',
        });


        $('.file-input-styled').uniform({
            fileButtonClass: 'action btn bg-primary tx-white'
        });

        $("#period").dateRangePicker({
            autoClose: false,
        });

        $("#pagesize").change(function(){
            $("#pagesize_form").submit();
        });

        $("#keyword_filter").change(function(){
            $("#keyword_filter_form").submit();
        });

        $("#btn-reset").click(function(){
            $("#search_company").val('');
            $("#search_supplier").val('').change();
            $("#search_reference_no").val('');
            $("#period").val('');
        });
        var toggle = 'desc';
        if($("#search_sort_date").val() == 'desc'){
            toggle = true;
        } else {
            toggle = false;
        }


        $(".sort-date").click(function(){
            let status = $("#search_sort_date").val();
            if (status == 'asc') {
                $("#search_sort_date").val('desc');
            } else {
                $("#search_sort_date").val('asc');
            }
            $("#searchForm").submit();
        })
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\Salam_Order\resources\views/pre_order/index.blade.php ENDPATH**/ ?>