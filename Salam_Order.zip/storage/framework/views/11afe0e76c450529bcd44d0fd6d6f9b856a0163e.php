<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('master/lib/imageviewer/css/jquery.verySimpleImageViewer.css')); ?>">
    <style>
        #image_preview {
            max-width: 600px;
            height: 600px;
        }
        .image_viewer_inner_container {
            width: 100% !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.purchase')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.details')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-info-circle"></i> <?php echo e(__('page.purchase_detail')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="row">
                    <div class="col-12 col-lg-4">
                        <div class="card card-body tx-white-8 bg-success mg-y-10 bd-0 ht-150 purchase-card">
                            <div class="row">
                                <div class="col-3">
                                    <span class="card-icon tx-70"><i class="fa fa-plug"></i></span>
                                </div>
                                <div class="col-9">
                                    <h4 class="card-title tx-white tx-medium mg-b-10"><?php echo e(__('page.supplier')); ?></h4>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.name')); ?>: <?php if(isset($purchase->supplier->name)): ?><?php echo e($purchase->supplier->name); ?><?php endif; ?></p>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.email')); ?>: <?php if(isset($purchase->supplier->email)): ?><?php echo e($purchase->supplier->email); ?><?php endif; ?></p>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.phone')); ?>: <?php if(isset($purchase->supplier->phone_number)): ?><?php echo e($purchase->supplier->phone_number); ?><?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="card card-body bg-teal tx-white mg-y-10 bd-0 ht-150 purchase-card">
                            <div class="row">
                                <div class="col-3">
                                    <span class="card-icon tx-70"><i class="fa fa-truck"></i></span>
                                </div>
                                <div class="col-9">
                                    <h4 class="card-title tx-white tx-medium mg-b-10"><?php echo e(__('page.store')); ?></h4>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.name')); ?>: <?php if(isset($purchase->store->name)): ?><?php echo e($purchase->store->name); ?><?php endif; ?></p>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.company')); ?>: <?php if(isset($purchase->store->company->name)): ?><?php echo e($purchase->store->company->name); ?><?php endif; ?></p>
                                    <p class="tx-16 mg-b-3"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="card card-body bg-info tx-white-8 mg-y-10 bd-0 ht-150 purchase-card">
                            <div class="row">                                
                                <div class="col-3">
                                    <span class="card-icon tx-70"><i class="fa fa-file-text-o"></i></span>
                                </div>
                                <div class="col-9">
                                    <h4 class="card-title tx-white tx-medium mg-b-10"><?php echo e(__('page.reference')); ?></h4>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.number')); ?>: <?php echo e($purchase->reference_no); ?></p>
                                    <p class="tx-16 mg-b-3"><?php echo e(__('page.date')); ?>: <?php echo e($purchase->timestamp); ?></p>
                                    <p class="tx-16 mg-b-3">
                                        <?php echo e(__('page.attachment')); ?>: 
                                        <?php if($purchase->attachment != ""): ?>
                                            <a href="#" class="attachment" data-value="<?php echo e($purchase->attachment); ?>">&nbsp;&nbsp;&nbsp;<i class="fa fa-paperclip"></i></a>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-t-20">
                    <div class="col-md-12">
                        <h5>Supplier Note</h5>
                        <p class="mx-2"><?php if(isset($purchase->supplier->note)): ?><?php echo e($purchase->supplier->note); ?><?php endif; ?></p>
                    </div>
                </div>
                <div class="row mg-t-20">
                    <div class="col-md-12 table-responsive">
                        <h5>Orders Item</h5>
                        <table class="table table-bordered table-colored table-info">
                            <thead>
                                <tr>
                                    <th class="wd-40">#</th>
                                    <th><?php echo e(__('page.product_name_code')); ?></th>
                                    <th><?php echo e(__('page.product_cost')); ?></th>
                                    <th><?php echo e(__('page.quantity')); ?></th>
                                    <th><?php echo e(__('page.product_tax')); ?></th>
                                    <th><?php echo e(__('page.subtotal')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $total_quantity = 0;
                                    $total_tax_rate = 0;
                                    $total_amount = 0;
                                    $paid = $purchase->payments()->sum('amount');
                                ?>
                                <?php $__currentLoopData = $purchase->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $tax = $item->product->tax->rate;
                                    $quantity = $item->quantity;
                                    $cost = $item->cost;
                                    $tax_rate = $cost * $tax / 100;
                                    $subtotal = $item->subtotal;

                                    $total_quantity += $quantity;
                                    $total_tax_rate += $tax_rate;
                                    $total_amount += $subtotal;
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php if(isset($item->product->name)): ?><?php echo e($item->product->name); ?> (<?php echo e($item->product->code); ?>)<?php endif; ?></td>
                                        <td><?php echo e($item->cost); ?></td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td><?php if(isset($item->product->tax->name)): ?><?php echo e($item->product->tax->name); ?><?php endif; ?></td>
                                        <td><?php echo e($item->subtotal); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="3" class="tx-bold" style="text-align:right"><?php echo e(__('page.total')); ?> (COP)</td>
                                    <td><?php echo e($total_quantity); ?></td>
                                    <td><?php echo e($total_tax_rate); ?></td>
                                    <td><?php echo e(number_format($total_amount)); ?></td>
                                </tr>
                            </tbody>
                            <tfoot class="tx-bold tx-black">
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.discount')); ?> (COP)</td>
                                    <td>
                                        <?php if(strpos( $purchase->discount_string , '%' ) !== false): ?>
                                            <?php echo e($purchase->discount_string); ?> (<?php echo e(number_format($purchase->discount)); ?>)
                                        <?php else: ?>
                                            <?php echo e(number_format($purchase->discount)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.shipping')); ?> (COP)</td>
                                    <td>
                                        <?php if(strpos( $purchase->shipping_string , '%' ) !== false): ?>
                                            <?php echo e($purchase->shipping_string); ?> (<?php echo e(number_format($purchase->shipping)); ?>)
                                        <?php else: ?>
                                            <?php echo e(number_format($purchase->shipping)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.returns')); ?></td>
                                    <td>
                                        <?php echo e(number_format($purchase->returns)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.total_amount')); ?> (COP)</td>
                                    <td><?php echo e(number_format($purchase->grand_total)); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.paid')); ?> (COP)</td>
                                    <td><?php echo e(number_format($paid)); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="text-align:right"><?php echo e(__('page.balance')); ?> (COP)</td>
                                    <td><?php echo e(number_format($purchase->grand_total - $paid)); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="row mg-t-20">
                    <div class="col-md-12">
                        <h5><?php echo e(__('page.note')); ?></h5>
                        <p class="mx-2"><?php echo e($purchase->note); ?></p>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-6 col-md-4 card card-body tx-white-8 bg-success mg-l-15 bd-0 d-block" style="float:right !important;">                            
                        <h6 class="card-title tx-white tx-medium mg-b-5"><?php echo e(__('page.created_by')); ?> <?php if(isset($purchase->user->name)): ?><?php echo e($purchase->user->name); ?><?php endif; ?></h6>
                        <h6 class="card-title tx-white tx-medium mg-y-5"><?php echo e(__('page.created_at')); ?> <?php echo e($purchase->created_at); ?></h6>
                    </div>
                    <div class="col-6 col-md-7 text-right">
                        <a href="<?php echo e(route('purchase.index')); ?>" class="btn btn-secondary"><i class="fa fa-credit-card"></i>  <?php echo e(__('page.purchases_list')); ?></a>
                        <a href="<?php echo e(route('payment.index', ['purchase', $purchase->id])); ?>" class="btn btn-info"><i class="icon ion-cash"></i>     <?php echo e(__('page.payment_list')); ?></a>
                    </div>
                </div>
            </div>
        </div>                
    </div>

    <div class="modal fade" id="attachModal">
        <div class="modal-dialog" style="margin-top:17vh">
            <div class="modal-content">
                <div id="image_preview"></div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/imageviewer/js/jquery.verySimpleImageViewer.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $(".attachment").click(function(e){
            e.preventDefault();
            let path = '<?php echo e(asset("/")); ?>' + $(this).data('value');
            console.log(path)
            // $("#attachment").attr('src', path);
            $("#image_preview").html('')
            $("#image_preview").verySimpleImageViewer({
                imageSource: path,
                frame: ['100%', '100%'],
                maxZoom: '900%',
                zoomFactor: '10%',
                mouse: true,
                keyboard: true,
                toolbar: true,
            });
            $("#attachModal").modal();
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\Salam_Order\resources\views/purchase/detail.blade.php ENDPATH**/ ?>