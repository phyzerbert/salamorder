<form action="" class="form-inline float-right" method="post" id="keyword_filter_form">
    <?php echo csrf_field(); ?>    
    <input type="text" name="keyword" id="keyword_filter" value="<?php echo e($keyword); ?>" class="form-control form-control-sm" placeholder="Keyword" />
</form><?php /**PATH E:\2019-Jun\Store\Source\Salam_Order\resources\views/elements/keyword.blade.php ENDPATH**/ ?>